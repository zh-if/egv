#!/bin/bash

function parse_yaml {
   local prefix=$2
   local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
   sed -ne "s|^\($s\):|\1|" \
        -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
        -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p"  $1 |
   awk -F$fs '{
      indent = length($1)/2;
      vname[indent] = $2;
      for (i in vname) {if (i > indent) {delete vname[i]}}
      if (length($3) > 0) {
         vn=""; for (i=0; i<indent; i++) {vn=(vn)(vname[i])("_")}
         printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, $2, $3);
      }
   }'
}

eval $(parse_yaml /opt/unetlab/go/agent-config.yaml)

# Detecting new disk and resize Root Filesystem

# VM env ????
cat /proc/cpuinfo | grep -q hypervisor
if [ $? == 0 ]; then \
	echo Running Virtual Environment...
	echo Check new disks
	disks=$(dmesg | grep 'SCSI disk' | sed -e 's/.*\[//' -e 's/\].*//')
	for disk in $disks ; do \
		pvs | grep -q $disk
		if [ $? != 0 ]; then \
			# New disk found
			echo New disk $disk found
			pvcreate /dev/$disk
			echo -n "Detecting VG...."
			VGS=$(vgs --noheading | awk '{print $1}')
			echo $VGS
			vgextend $VGS /dev/$disk
			echo -n "Detecting ROOT FS..."
			ROOTLV=$(mount | grep ' / ' | awk '{print $1}')
			echo $ROOTLV
			lvextend -l +100%FREE $ROOTLV	
			echo Resizing ROOT FS
			resize2fs $ROOTLV
		fi
	done
fi

# Enable or Disable UKSM
if [[ -e /sys/kernel/mm/ksm/run ]]; then 
    if [[ -e /opt/unetlab/ksm ]]; then
        cat /opt/unetlab/ksm > /sys/kernel/mm/ksm/run
    fi
fi

# tune nat and bip for docker
iptables -P FORWARD ACCEPT

# Block xml.cisco.com resolution
iptables -I OUTPUT -p udp --dport 53 -m string --hex-string "|03|xml|05|cisco|03|com" --algo bm -j DROP

#Create cpulimit cgroup
cgcreate -g pids:/cpulimit

# Tune bridge for nat

sysctl -w net.bridge.bridge-nf-call-arptables=0
sysctl -w net.bridge.bridge-nf-call-ip6tables=0
sysctl -w net.bridge.bridge-nf-call-iptables=0

# Disable numa balancing
sysctl -w kernel.numa_balancing=0

echo "Eve-NG Sat  (default root password is 'eve')" > /etc/issue

fgrep -e vmx -e svm /proc/cpuinfo 2>&1 > /dev/null
if [[ $? -eq 0 ]]; then
cat >> /etc/issue << EOF

EOF
echo "10000" > /sys/module/kvm/parameters/halt_poll_ns
#echo "0" > /sys/module/kvm/parameters/halt_poll_ns
else
cat >> /etc/issue << EOF

WARNING: neither Intel VT-x or AMD-V found

EOF
fi
# set the right templates

fgrep -e vmx -e svm /proc/cpuinfo 2>&1 > /dev/null 
if [[ $? -eq 0 ]]; then
echo N > /sys/module/kvm/parameters/report_ignored_msrs
echo Y > /sys/module/kvm/parameters/ignore_msrs
fi
systemd-detect-virt -v > /opt/unetlab/hypervisor

#Tune cggroup
#echo "/opt/unetlab/scripts/remove-empty-cpu-cgroup.sh" > /sys/fs/cgroup/cpu/release_agent
#echo "/opt/unetlab/scripts/remove-empty-memory-cgroup.sh" > sys/fs/cgroup/memory/release_agent

#Fix udev nbd
sed -i -e 's/nbd\*|//' /usr/lib/udev/rules.d/60-block.rules  2>&1 > /dev/null
#Fix udev hotplug for vun interfaces
sed -i -e 's/.*ifupdown-hotplug"/SUBSYSTEM=="net", KERNEL!="vun*|vnet*|xun*|tap2xlan*", ACTION=="add|remove", RUN+="ifupdown-hotplug"/' /lib/udev/rules.d/80-ifupdown.rules  2>&1 > /dev/null
#tune landscape
dpkg -s landscape-common > /dev/null 2>&1
if [[ $? -eq 0 ]]; then
	echo landscape-common        landscape-common/sysinfo  select  "Do not display sysinfo on login" | debconf-set-selections
	dpkg-reconfigure -fnoninteractive landscape-common
fi
