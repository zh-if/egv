#!/bin/bash

whoami | grep root || ( echo  setup wizard require root access. use sudo -i to get root elevation ; exit 0 )

# Check if VM is alredy configured
if [[ -e /opt/ovf/.configured ]]; then
    exit
fi

. ~/.profile

#clean old conf
rm -f /etc/wireguard/*
ip link del wg0

TITLE="Eve-NG SAT - Setup"

#pickup first nic
nic=$(ls -1 /sys/class/net | grep -v "docker\|lo\|wg0" | head -1) 

# Setting root password
ovf_root_password='uninitialized'
while [[ ${ovf_root_password} != ${ovf_root_repeat_password} ]]; do
	ovf_root_password=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Root Password' --passwordbox 'Type the Root Password:' 8 40 '')
	ovf_root_repeat_password=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Root Password' --passwordbox 'Repeat the Root Password:' 8 40 '')
	if [[ ${ovf_root_password} != ${ovf_root_repeat_password} ]]; then
		dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Root Password' --msgbox '\nPasswords do not match.' 7 40
	else
		echo root:"${ovf_root_password}" | chpasswd 2>&1 > /dev/null
        if [ $? -ne 0 ]; then
            dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Root Password' --msgbox '\nFailed to change password.' 7 40
        fi
	fi
done

# Checking if ovf parameters exist
vmtoolsd --cmd "info-get guestinfo.ovfEnv" 2> /dev/null > /opt/ovf/ovf.xml

if [ $? -eq 0 ]; then
	# Using ovf parameters from ESXi
	xsltproc /opt/ovf/ovf.xsl /opt/ovf/ovf.xml | sed 's/vami\.//' | sed 's/\.unetlab//' > /opt/ovf/ovf_vars
	. /opt/ovf/ovf_vars
else
	# Using interactive input
	ovf_hostname=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Hostname' --inputbox 'Type the short hostname for the system:' 9 40 'eve-sat')
	ovf_domain=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'DNS domain name' --inputbox 'Type the DNS domain name for the system:' 9 40 'example.com')
	ovf_dhcp=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Use DHCP/Static IP Address' --radiolist 'Use DHCP or Static IP Address for the network adapter on Management Network?' 11 40 2 'dhcp' '' 'on' 'static' '' 'off')

	if [[ "${ovf_dhcp}" = 'static' ]]; then
		# If DHCP is not used, ask for IP address/netmask/gateway/dns
		ovf_ip=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Management Network IP Address' --inputbox 'Type the IP address for the Management Network:' 9 40 '')
		ovf_netmask=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Management Network Subnet Mask' --inputbox 'Type the Subnet Mask for the Management Network:' 9 40 '')
		ovf_gateway=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Management Network Default Gateway' --inputbox 'Type the Default Gateway for the Management Network:' 9 40 '')
		ovf_dns1=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Primary DNS server' --inputbox 'Type the IP IP address of primary DNS server:' 9 40 '')
		ovf_dns2=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Secondary DNS server' --inputbox 'Type the IP address of secondary DNS server:' 9 40 '')
	fi

	ovf_ntp=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'NTP server' --inputbox 'Type the hostname/IP address of NTP for initial clock sync (leave empty if not used):' 10 40 '')

	ovf_proxy_type=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server configuration' --radiolist 'Choose how the VM can connect to the Internet.' 11 40 3 'direct connection' '' 'on' 'anonymous proxy' '' 'off' 'authenticated proxy' '' 'off')
	if [[ ${ovf_proxy_type} = 'anonymous proxy' || ${ovf_proxy_type} = 'authenticated proxy' ]]; then
		ovf_proxy_url=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server and port' --inputbox 'Type the Proxy Server URL:' 8 40 'proxy.example.com:8080')
	fi
	if [[ ${ovf_proxy_type} = 'authenticated proxy' ]]; then
		ovf_proxy_username=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server Username' --inputbox 'Type the Proxy Server Username:' 8 40 '')
		ovf_proxy_password='uninitialized'
		while [[ ${ovf_proxy_password} != ${ovf_proxy_repeat_password} ]]; do
			ovf_proxy_password=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server Password' --passwordbox 'Type the Proxy Server Password:' 8 40 '')
			ovf_proxy_repeat_password=$(dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server Password' --passwordbox 'Repeat the Proxy Server Password:' 8 40 '')
			if [[ ${ovf_proxy_password} != ${ovf_proxy_repeat_password} ]]; then
				dialog --backtitle "${TITLE}" --no-cancel --stdout --title 'Proxy Server Password' --msgbox '\nPasswords do not match.' 7 40
			fi
		done
	fi
fi

# Setting Hostname and Domain Name
echo ${ovf_hostname} > /etc/hostname
sed -i "s/127.0.1.1.*/127.0.1.1\t${ovf_hostname}.${ovf_domain}\t${ovf_hostname}/g" /etc/hosts


mask2cdr ()
{
   # Assumes there's no "255." after a non-255 byte in the mask
   local x=${1##*255.}
   set -- 0^^^128^192^224^240^248^252^254^ $(( (${#1} - ${#x})*2 )) ${x%%.*}
   x=${1%%$3*}
   echo $(( $2 + (${#x}/4) ))
}


# Setting Management Network Netplan Method
rm -f /etc/netplan/*
if [[ "${ovf_dhcp}" = 'static' ]]; then
	mask=$(mask2cdr ${ovf_netmask})
	cat > /etc/netplan/01-netcfg.yaml << EOF
# This file describes the network interfaces available on your system
# For more information, see netplan(5).
network:
  version: 2
  renderer: networkd
  ethernets:
    $nic:
      addresses: [ "${ovf_ip}/${mask}" ]
      gateway4: ${ovf_gateway}
      nameservers:
        addresses: [ "${ovf_dns1}", "${ovf_dns2}" ]
EOF
	sed -i -e 's/#\?DNS=.*/DNS='${ovf_dns1}'/' /etc/systemd/resolved.conf
	sed -i -e 's/#\?FallbackDNS=.*/FallbackDNS='${ovf_dns2}'/' /etc/systemd/resolved.conf
else
	cat > /etc/netplan/01-netcfg.yaml << EOF
# This file describes the network interfaces available on your system
# For more information, see netplan(5).
network:
  version: 2
  renderer: networkd
  ethernets:
    $nic:
      dhcp4: yes
EOF
	sed -i -e 's/#\?DNS=.*/#DNS=/' /etc/systemd/resolved.conf
	sed -i -e 's/#\?FallbackDNS=.*/#FallbackDNS=/' /etc/systemd/resolved.conf
fi

# Setting the NTP server
if [ "${ovf_ntp}" != '' ]; then
    sed -i 's/NTPDATE_USE_NTP_CONF=.*/NTPDATE_USE_NTP_CONF=no/g' /etc/default/ntpdate 2>/dev/null
    sed -i 's/NTPSERVERS=.*/NTPSERVERS=${ovf_ntp}/g' /etc/default/ntpdate 2>/dev/null
    sed -i -e 's/#\?NTP=.*/#NTP=/' /etc/systemd/timesyncd.conf 2>/dev/null
else
    sed -i 's/NTPDATE_USE_NTP_CONF=.*/NTPDATE_USE_NTP_CONF=yes/g' /etc/default/ntpdate 2>/dev/null
    sed -i 's/NTPSERVERS=.*/NTPSERVERS=/g' /etc/default/ntpdate 2>/dev/null
    sed -i -e 's/#\?NTP=.*/NTP=${ovf_ntp}/' /etc/systemd/timesyncd.conf 2>/dev/null
fi

# Setting the proxy server
if [ "${ovf_proxy_type}" = "direct connection" ]; then
    rm -f /etc/apt/apt.conf.d/00proxy
elif [ "${ovf_proxy_type}" = "anonymous proxy" ]; then
    echo Acquire::http::Proxy "http://${ovf_proxy_url}/" > /etc/apt/apt.conf.d/00proxy
    echo Acquire::https::Proxy "http://${ovf_proxy_url}/" >> /etc/apt/apt.conf.d/00proxy
    echo Acquire::ftp::Proxy "http://${ovf_proxy_url}/" >> /etc/apt/apt.conf.d/00proxy
elif [ "${ovf_proxy_type}" = "authenticated proxy" ]; then
    echo "Acquire::http::Proxy \"http://${ovf_proxy_username}:${ovf_proxy_password}@${ovf_proxy_url}/\";" > /etc/apt/apt.conf.d/00proxy
    echo "Acquire::https::Proxy \"http://${ovf_proxy_username}:${ovf_proxy_password}@${ovf_proxy_url}/\";" >> /etc/apt/apt.conf.d/00proxy
    echo "Acquire::ftp::Proxy \"http://${ovf_proxy_username}:${ovf_proxy_password}@${ovf_proxy_url}/\";" >> /etc/apt/apt.conf.d/00proxy
fi

# Cleaning
rm -rf /etc/ssh/ssh_host_* /root/.Xauthority /root/.ssh /root/.bash_history /tmp/ssh* /tmp/netio* /tmp/vmware* /opt/ovf/ovf_vars /opt/ovf/ovf.xml /root/.bash_history /root/.cache
find /var/log -type f -exec rm -f {} \;
find /var/lib/apt/lists -type f -exec rm -f {} \;
find /opt/unetlab/data/Logs -type f -exec rm -f {} \;
touch /var/log/wtmp
chown root:utmp /var/log/wtmp
chmod 664 /var/log/wtmp
apt-get clean
dpkg-reconfigure openssh-server

# Ending and rebooting
touch /opt/ovf/.configured
reboot
