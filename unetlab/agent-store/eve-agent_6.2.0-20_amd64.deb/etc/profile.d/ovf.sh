alias dc='docker -H tcp://127.0.0.1:4243'
NEEDRESTART_SUSPEND=y
/opt/ovf/agentconfig.sh
