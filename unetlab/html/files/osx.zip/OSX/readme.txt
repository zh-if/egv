1. Reboot your Mac and hold the CMD + R keys
2. When presented with the recovery options, click Utilities at the top and choose Terminal
3. Type: csrutil disable
4. Reboot as normal
5. in a terminal type: sudo mount -uw / 
6. copy ftp and telnet binaries in /usr/bin folder
7. in a terminal type: sudo chmod +xr /usr/bin/telnet
8. in a terminal type: sudo chmod +xr /usr/bin/ftp
9. Reboot your Mac and hold the CMD + R keys
10. When presented with the recovery options, click Utilities at the top and choose Terminal
11. Type: csrutil enable
12. Reboot as normal
